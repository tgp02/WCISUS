A Pen created at CodePen.io. You can find this one at https://codepen.io/tgp02/pen/ajgqQv.

 This is a clock that counts down 10 minutes from when the user arrives at the page.